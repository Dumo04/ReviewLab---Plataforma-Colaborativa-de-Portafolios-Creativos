(function() {
    var form = document.getElementById('project-form');
    var submitBtn = document.getElementById('submit-btn');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        clearMessage('form-message');

        var title = document.getElementById('title').value.trim();
        var description = document.getElementById('description').value.trim();
        var image_url = document.getElementById('image_url').value.trim();

        if (!title || !description) {
            showMessage('form-message', 'El titulo y la descripcion son obligatorios', 'error');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = 'Creando...';

        fetch(API_URL + '/projects', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: title, description: description, image_url: image_url })
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.status === 'success') {
                showMessage('form-message', 'Proyecto creado exitosamente! Redirigiendo...', 'success');
                setTimeout(function() {
                    window.location.href = 'index.html';
                }, 1500);
            } else {
                showMessage('form-message', data.message || 'Error al crear el proyecto', 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Crear Proyecto';
            }
        })
        .catch(function(err) {
            showMessage('form-message', 'Error de conexion con el servidor', 'error');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Crear Proyecto';
            console.error(err);
        });
    });
})();
