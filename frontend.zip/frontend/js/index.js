(function() {
    var container = document.getElementById('projects-container');

    fetch(API_URL + '/projects')
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.status === 'success' && data.data && data.data.length > 0) {
                var html = '<div class="projects-grid">';
                data.data.forEach(function(project) {
                    var img = project.image_url || 'https://via.placeholder.com/400x200?text=Sin+Imagen';
                    var desc = project.description.length > 150
                        ? project.description.substring(0, 150) + '...'
                        : project.description;
                    html += '<div class="project-card" onclick="window.location.href=\'detalle.html?id=' + project.id + '\'">' +
                        '<img src="' + img + '" alt="' + project.title + '" class="project-card-img">' +
                        '<div class="project-card-body">' +
                        '<h3 class="project-card-title">' + project.title + '</h3>' +
                        '<p class="project-card-desc">' + desc + '</p>' +
                        '<a href="detalle.html?id=' + project.id + '" class="project-card-link">Ver detalles</a>' +
                        '</div></div>';
                });
                html += '</div>';
                container.innerHTML = html;
            } else {
                container.innerHTML = '<div class="empty-state">' +
                    '<p>No hay proyectos todavia. Se el primero en crear uno.</p>' +
                    '<a href="crear.html" class="btn btn-primary">Crear Proyecto</a>' +
                    '</div>';
            }
        })
        .catch(function(err) {
            container.innerHTML = '<div class="error-message">No se pudieron cargar los proyectos</div>';
            console.error(err);
        });
})();
