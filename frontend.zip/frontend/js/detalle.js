(function() {
    var params = new URLSearchParams(window.location.search);
    var id = params.get('id');
    var container = document.getElementById('project-detail');

    if (!id) {
        container.innerHTML = '<div class="error-message">ID de proyecto no especificado</div>' +
            '<br><a href="index.html" class="btn btn-primary">Volver a proyectos</a>';
        return;
    }

    fetch(API_URL + '/projects/' + id)
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.status === 'success' && data.data) {
                var project = data.data;
                var img = project.image_url || 'https://via.placeholder.com/800x400?text=Sin+Imagen';
                var date = new Date(project.created_at).toLocaleDateString('es-ES');

                container.innerHTML = '<div class="detail-container">' +
                    '<img src="' + img + '" alt="' + project.title + '" class="detail-image">' +
                    '<div class="detail-body">' +
                    '<h1 class="detail-title">' + project.title + '</h1>' +
                    '<p class="detail-date">Creado: ' + date + '</p>' +
                    '<div class="detail-description"><p>' + project.description + '</p></div>' +
                    '<br><a href="index.html" class="btn btn-primary">Volver a proyectos</a>' +
                    '</div></div>';
            } else {
                container.innerHTML = '<div class="error-message">Proyecto no encontrado</div>' +
                    '<br><a href="index.html" class="btn btn-primary">Volver a proyectos</a>';
            }
        })
        .catch(function(err) {
            container.innerHTML = '<div class="error-message">No se pudo cargar el proyecto</div>' +
                '<br><a href="index.html" class="btn btn-primary">Volver a proyectos</a>';
            console.error(err);
        });
})();
