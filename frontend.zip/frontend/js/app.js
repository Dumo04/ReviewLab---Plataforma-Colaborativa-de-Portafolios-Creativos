var API_URL = 'http://localhost:3000/api';

function showMessage(containerId, message, type) {
    var container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = '<div class="' + (type === 'error' ? 'error-message' : 'success-message') + '">' + message + '</div>';
}

function clearMessage(containerId) {
    var container = document.getElementById(containerId);
    if (container) container.innerHTML = '';
}
