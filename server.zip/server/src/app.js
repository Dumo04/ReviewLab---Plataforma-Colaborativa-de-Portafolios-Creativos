require('dotenv').config();
const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth.routes');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'ReviewLab Backend is running',
    timestamp: new Date().toISOString()
  });
});

app.use('/api/auth', authRoutes);

// Placeholder for projects routes
app.use('/api/projects', (req, res) => {
  res.status(200).json({ message: 'Projects endpoint - coming soon' });
});

app.use((req, res) => {
  res.status(404).json({
    status: 'error',
    message: 'Route not found'
  });
});

module.exports = app;
