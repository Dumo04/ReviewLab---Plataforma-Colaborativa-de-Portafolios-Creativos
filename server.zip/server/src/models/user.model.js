const { readData, writeData } = require('../config/mockDatabase');

class UserModel {
  static async findByEmail(email) {
    const data = readData();
    return data.users.find(u => u.email === email) || null;
  }

  static async findById(id) {
    const data = readData();
    const user = data.users.find(u => u.id === id);
    if (user) {
      const { password_hash, ...safeUser } = user;
      return safeUser;
    }
    return null;
  }

  static async create(name, email, passwordHash) {
    const data = readData();
    const newUser = {
      id: data.nextUserId,
      name,
      email,
      password_hash: passwordHash,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    data.users.push(newUser);
    data.nextUserId += 1;
    writeData(data);
    
    const { password_hash, ...safeUser } = newUser;
    return safeUser;
  }

  static async findByEmailWithPassword(email) {
    const data = readData();
    return data.users.find(u => u.email === email) || null;
  }
}

module.exports = UserModel;
