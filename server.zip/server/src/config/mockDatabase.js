const fs = require('fs');
const path = require('path');

const dbFilePath = path.join(__dirname, '../../data.json');

const initializeDataFile = () => {
  if (!fs.existsSync(dbFilePath)) {
    const initialData = {
      users: [],
      projects: [],
      nextUserId: 1,
      nextProjectId: 1
    };
    fs.writeFileSync(dbFilePath, JSON.stringify(initialData, null, 2));
  }
};

const readData = () => {
  try {
    const data = fs.readFileSync(dbFilePath, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    initializeDataFile();
    return JSON.parse(fs.readFileSync(dbFilePath, 'utf-8'));
  }
};

const writeData = (data) => {
  fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2));
};

initializeDataFile();

module.exports = {
  readData,
  writeData,
  dbFilePath
};
