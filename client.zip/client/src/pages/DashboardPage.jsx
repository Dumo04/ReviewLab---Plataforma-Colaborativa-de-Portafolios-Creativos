import { authService } from '../services/authService';
import { Navbar } from '../components/Navbar';

export function DashboardPage() {
  const user = authService.getCurrentUser();

  return (
    <>
      <Navbar />
      <div className="dashboard-container">
        <div className="dashboard-content">
          <h1>Welcome, {user?.name}!</h1>
          <p>You're logged in to ReviewLab</p>
          <p className="dashboard-info">This is the main dashboard. Project features coming soon!</p>
        </div>
      </div>
    </>
  );
}
