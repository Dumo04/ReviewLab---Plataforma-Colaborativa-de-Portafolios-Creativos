const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data.json');

// --- Middleware ---
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../frontend')));

// --- Mock Database ---
function initDB() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ projects: [], nextId: 1 }, null, 2));
  }
}

function readDB() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } catch {
    initDB();
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  }
}

function writeDB(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

initDB();

// --- Routes ---

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'ReviewLab API running' });
});

// List all projects
app.get('/api/projects', (req, res) => {
  const data = readDB();
  const projects = data.projects.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json({ status: 'success', data: projects, count: projects.length });
});

// Get single project
app.get('/api/projects/:id', (req, res) => {
  const data = readDB();
  const project = data.projects.find(p => p.id === parseInt(req.params.id));
  if (!project) return res.status(404).json({ status: 'error', message: 'Project not found' });
  res.json({ status: 'success', data: project });
});

// Create project
app.post('/api/projects', (req, res) => {
  const { title, description, image_url } = req.body;

  if (!title || !title.trim()) {
    return res.status(400).json({ status: 'error', message: 'Title is required' });
  }
  if (!description || !description.trim()) {
    return res.status(400).json({ status: 'error', message: 'Description is required' });
  }

  const data = readDB();
  const project = {
    id: data.nextId,
    title: title.trim(),
    description: description.trim(),
    image_url: image_url || null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  data.projects.push(project);
  data.nextId += 1;
  writeDB(data);

  res.status(201).json({ status: 'success', message: 'Project created', data: project });
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// --- Error handler ---
app.use((err, req, res, next) => {
  console.error('[ERROR]', err);
  res.status(err.status || 500).json({ status: 'error', message: err.message || 'Internal Server Error' });
});

// --- Start server ---
app.listen(PORT, () => {
  console.log(`ReviewLab running on http://localhost:${PORT}`);
});
